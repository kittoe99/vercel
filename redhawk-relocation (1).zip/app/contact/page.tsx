import type { Metadata } from "next"
import { MainNav } from "@/components/main-nav"
import { HawkFooter } from "@/components/hawk-footer"
import { ScrollProgressBar } from "@/components/scroll-progress-bar"
import { ContactSection } from "@/components/contact-section"

export const metadata: Metadata = {
  title: "Contact Redhawk Relocation | Moving Help Marketplace | Phoenix, AZ",
  description:
    "Contact Redhawk Relocation's marketplace support team to learn more about booking independent moving helpers or joining our platform as a helper. Reach us by phone or online form.",
  keywords:
    "contact moving marketplace, moving help support, book moving helpers, join moving platform, moving help questions",
  alternates: {
    canonical: "https://redhawkrelocation.com/contact",
  },
  openGraph: {
    title: "Contact Redhawk Relocation | Moving Help Marketplace",
    description:
      "Contact Redhawk Relocation's marketplace support team to learn more about booking independent moving helpers or joining our platform as a helper.",
    url: "https://redhawkrelocation.com/contact",
    images: [
      {
        url: "/moving-truck-hero.png",
        width: 1200,
        height: 630,
        alt: "Redhawk Relocation marketplace",
      },
    ],
  },
}

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />
      <ScrollProgressBar />
      <ContactSection />
      <HawkFooter />
    </div>
  )
}
