import { notFound } from "next/navigation"
import type { Metadata } from "next"
import { MainNav } from "@/components/main-nav"
import { HawkFooter } from "@/components/hawk-footer"
import { ScrollProgressBar } from "@/components/scroll-progress-bar"

// Define the cities we support
const supportedCities = [
  "austin",
  "nashville",
  "boise",
  "raleigh",
  "phoenix",
  "tampa",
  "charlotte",
  "denver",
  "columbus",
  "salt-lake-city",
]

export async function generateStaticParams() {
  return supportedCities.map((city) => ({
    city,
  }))
}

export async function generateMetadata({ params }: { params: { city: string } }): Promise<Metadata> {
  // Check if this is a supported city
  if (!supportedCities.includes(params.city)) {
    return {
      title: "City Not Found | Redhawk Relocation",
      description: "The requested city page was not found.",
    }
  }

  // Format city name for display (e.g., "salt-lake-city" -> "Salt Lake City")
  const formattedCity = params.city
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return {
    title: `${formattedCity} Moving Help | Redhawk Relocation`,
    description: `Professional moving help in ${formattedCity}. Local, commercial, and specialty moving assistance for ${formattedCity} and surrounding areas.`,
    alternates: {
      canonical: `https://redhawkrelocation.com/locations/${params.city}`,
    },
  }
}

export default function CityPage({ params }: { params: { city: string } }) {
  // Check if this is a supported city
  if (!supportedCities.includes(params.city)) {
    notFound()
  }

  // Format city name for display (e.g., "salt-lake-city" -> "Salt Lake City")
  const formattedCity = params.city
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  // Import the CitySpecificContent component
  const { default: CitySpecificContent, cityData } = require("@/components/city-specific-content")

  return (
    <div className="min-h-screen">
      <MainNav />
      <ScrollProgressBar />

      {/* Use the CitySpecificContent component with the appropriate city data */}
      {cityData[params.city] && <CitySpecificContent cityInfo={cityData[params.city]} />}

      {/* Fallback if city data is not found */}
      {!cityData[params.city] && (
        <div className="container mx-auto px-4 py-16">
          <h1 className="text-3xl font-bold text-center">Welcome to {formattedCity}</h1>
          <p className="text-center mt-4">Information about our services in {formattedCity} is coming soon.</p>
        </div>
      )}

      <HawkFooter />
    </div>
  )
}
