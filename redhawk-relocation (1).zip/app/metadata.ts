export const metadata = {
  title: "Get a Moving Quote | Redhawk Relocation",
  description:
    "Get a free moving quote from Redhawk Relocation. Fast, accurate estimates for local and long-distance moves in Phoenix, AZ and surrounding areas.",
}
