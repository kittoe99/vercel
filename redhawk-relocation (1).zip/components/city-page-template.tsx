"use client"

import Image from "next/image"
import Link from "next/link"
import { MapPin, Phone, Clock, CheckCircle, Star, Calendar, Info, Truck, Home } from "lucide-react"
import { Button } from "@/components/ui/button"

export interface CityPageProps {
  city: string
  state: string
  heroImage: string
  description: string
  features: string[]
  testimonial?: {
    quote: string
    author: string
    rating: number
    image?: string
  }
  faqs: Array<{
    question: string
    answer: string
  }>
  nearbyAreas: string[]
  popularNeighborhoods?: Array<{
    name: string
    description: string
  }>
  movingTips?: string[]
  localResources?: Array<{
    name: string
    description: string
  }>
  seasonalInfo?: string
}

export function CityPageTemplate({
  city,
  state,
  heroImage,
  description,
  features,
  testimonial,
  faqs,
  nearbyAreas,
  popularNeighborhoods,
  movingTips,
  localResources,
  seasonalInfo,
}: CityPageProps) {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-secondary-900 to-secondary-800 text-white">
        <div className="absolute inset-0 opacity-20">
          <Image
            src={heroImage || "/placeholder.svg"}
            alt={`${city}, ${state} moving help`}
            fill
            className="object-cover"
            priority
          />
        </div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Moving Help in {city}, {state}
            </h1>
            <p className="text-lg md:text-xl opacity-90 mb-8">
              Professional, reliable moving help for your {city} relocation needs
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="bg-primary-600 hover:bg-primary-700">
                <Link href="/quote">Get a Free Quote</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="bg-white/10 text-white border-white/30 hover:bg-white/20"
              >
                <Link href="tel:+17208429167">
                  <Phone className="mr-2 h-5 w-5" />
                  (720) 842-9167
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Left Column - Main Content */}
            <div className="md:col-span-2">
              <h2 className="text-2xl md:text-3xl font-bold text-secondary-900 mb-6">Moving Help Services in {city}</h2>
              <div className="prose max-w-none mb-8">
                <p>{description}</p>
              </div>

              {/* Services */}
              <div className="bg-gray-50 rounded-xl p-6 mb-8">
                <h3 className="text-xl font-semibold text-secondary-900 mb-4">Our {city} Moving Help Includes:</h3>
                <ul className="space-y-3">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-primary-600 mr-3 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Popular Neighborhoods */}
              {popularNeighborhoods && popularNeighborhoods.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-semibold text-secondary-900 mb-4">
                    Popular {city} Neighborhoods We Serve
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {popularNeighborhoods.map((neighborhood, index) => (
                      <div key={index} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                        <h4 className="font-medium text-lg mb-2 text-secondary-800">{neighborhood.name}</h4>
                        <p className="text-gray-600">{neighborhood.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Seasonal Moving Info */}
              {seasonalInfo && (
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-6 mb-8">
                  <div className="flex items-start">
                    <Calendar className="h-6 w-6 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-xl font-semibold text-secondary-900 mb-2">Seasonal Moving Tips for {city}</h3>
                      <p className="text-gray-700">{seasonalInfo}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Moving Tips */}
              {movingTips && movingTips.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-semibold text-secondary-900 mb-4">{city} Moving Tips</h3>
                  <div className="bg-gray-50 rounded-xl p-6">
                    <ul className="space-y-4">
                      {movingTips.map((tip, index) => (
                        <li key={index} className="flex items-start">
                          <Info className="h-5 w-5 text-primary-600 mr-3 mt-0.5 flex-shrink-0" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* Testimonial */}
              {testimonial && (
                <div className="bg-secondary-50 rounded-xl p-6 mb-8 border border-secondary-100">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < testimonial.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <blockquote className="text-lg italic mb-4">"{testimonial.quote}"</blockquote>
                  <div className="flex items-center">
                    {testimonial.image && (
                      <div className="mr-3">
                        <Image
                          src={testimonial.image || "/placeholder.svg"}
                          alt={testimonial.author}
                          width={40}
                          height={40}
                          className="rounded-full"
                        />
                      </div>
                    )}
                    <div>
                      <p className="font-medium">{testimonial.author}</p>
                      <p className="text-sm text-gray-600">{city} Customer</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Local Resources */}
              {localResources && localResources.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-semibold text-secondary-900 mb-4">
                    Local Resources for New {city} Residents
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {localResources.map((resource, index) => (
                      <div key={index} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                        <h4 className="font-medium text-lg mb-2 text-secondary-800">{resource.name}</h4>
                        <p className="text-gray-600">{resource.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* FAQs */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-secondary-900 mb-6">
                  Frequently Asked Questions About {city} Moving
                </h3>
                <div className="space-y-6">
                  {faqs.map((faq, index) => (
                    <div key={index} className="border-b border-gray-200 pb-6">
                      <h4 className="text-lg font-medium text-secondary-900 mb-2">{faq.question}</h4>
                      <p className="text-gray-700">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Sidebar */}
            <div>
              {/* Contact Card */}
              <div className="bg-white rounded-xl shadow-md p-6 mb-6 sticky top-24">
                <h3 className="text-xl font-semibold text-secondary-900 mb-4">Contact Us</h3>
                <div className="space-y-4 mb-6">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-primary-600 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Service Area</p>
                      <p className="text-gray-600">
                        {city}, {state} and surrounding areas
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-primary-600 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-gray-600">(720) 842-9167</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Clock className="h-5 w-5 text-primary-600 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Hours</p>
                      <p className="text-gray-600">Mon-Sat: 8am - 8pm</p>
                      <p className="text-gray-600">Sun: 9am - 6pm</p>
                    </div>
                  </div>
                </div>
                <Button asChild className="w-full bg-primary-600 hover:bg-primary-700">
                  <Link href="/quote">Get a Free Quote</Link>
                </Button>
              </div>

              {/* Our Services */}
              <div className="bg-white rounded-xl shadow-md p-6 mb-6">
                <h3 className="text-xl font-semibold text-secondary-900 mb-4">Our Services</h3>
                <ul className="space-y-3">
                  <li>
                    <Link
                      href="/services#local-moving"
                      className="flex items-center text-gray-700 hover:text-primary-600 transition-colors"
                    >
                      <Truck className="h-5 w-5 mr-2 text-primary-600" />
                      <span>Local Moving Help</span>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/services#commercial-moving"
                      className="flex items-center text-gray-700 hover:text-primary-600 transition-colors"
                    >
                      <Home className="h-5 w-5 mr-2 text-primary-600" />
                      <span>Commercial Moving Help</span>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/services#specialty-moving"
                      className="flex items-center text-gray-700 hover:text-primary-600 transition-colors"
                    >
                      <CheckCircle className="h-5 w-5 mr-2 text-primary-600" />
                      <span>Specialty Moving Help</span>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/services#packing-services"
                      className="flex items-center text-gray-700 hover:text-primary-600 transition-colors"
                    >
                      <CheckCircle className="h-5 w-5 mr-2 text-primary-600" />
                      <span>Packing Services</span>
                    </Link>
                  </li>
                </ul>
              </div>

              {/* Areas We Serve */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-xl font-semibold text-secondary-900 mb-4">Areas We Serve</h3>
                <p className="mb-4">We provide moving help throughout {city} and nearby areas including:</p>
                <ul className="grid grid-cols-2 gap-2">
                  {nearbyAreas.map((area, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-primary-600 mr-2 flex-shrink-0" />
                      <span className="text-sm">{area}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-secondary-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Move in {city}?</h2>
          <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
            Get connected with professional movers in {city} today and experience a stress-free relocation.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild size="lg" className="bg-primary-600 hover:bg-primary-700">
              <Link href="/quote">Get a Free Quote</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-white/10 text-white border-white/30 hover:bg-white/20"
            >
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
