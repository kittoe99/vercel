import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Truck, Clock, DollarSign, CheckCircle, ShieldCheck, MapPin, Users } from "lucide-react"

interface CityInfo {
  name: string
  stateAbbr: string
  helperServices: string[]
  pricing: string
  availability: string
  helperQualifications: string[]
  commonRequests: string[]
  serviceAreas: string[]
}

interface CitySpecificContentProps {
  cityInfo: CityInfo
}

const cityData: Record<string, CityInfo> = {
  austin: {
    name: "Austin",
    stateAbbr: "TX",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Heavy item moving specialists",
      "Apartment and high-rise moving assistance",
      "Commercial office moving help",
    ],
    pricing:
      "Moving helpers in Austin typically charge between $35-$60 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Austin, with many offering extended hours during peak moving season (May-September). Early morning and evening appointments are available to avoid the Texas heat.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Texas moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Austin building regulations",
      "Equipped with proper moving tools",
    ],
    commonRequests: [
      "Help navigating downtown Austin parking restrictions",
      "Assistance with high-rise apartment moves",
      "Moving during extreme heat conditions",
      "University of Texas student moves",
      "Help with historic homes with narrow doorways",
    ],
    serviceAreas: [
      "Downtown Austin",
      "South Congress",
      "East Austin",
      "North Austin",
      "West Lake Hills",
      "Round Rock",
      "Cedar Park",
      "Georgetown",
      "Pflugerville",
      "Kyle and Buda",
    ],
  },
  nashville: {
    name: "Nashville",
    stateAbbr: "TN",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Musical instrument moving assistance",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Nashville typically charge between $30-$55 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Nashville, with flexible scheduling to work around major events like CMA Fest. Many helpers offer weekend and evening availability.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Tennessee moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Nashville building regulations",
      "Specialized in handling musical equipment",
    ],
    commonRequests: [
      "Help with downtown Nashville parking challenges",
      "Assistance moving musical instruments and equipment",
      "Moving in historic buildings with narrow staircases",
      "Help during major Nashville events",
      "Assistance with high-rise condo moves",
    ],
    serviceAreas: [
      "Downtown Nashville",
      "East Nashville",
      "The Gulch",
      "Germantown",
      "12 South",
      "Brentwood",
      "Franklin",
      "Hendersonville",
      "Mt. Juliet",
      "Murfreesboro",
    ],
  },
  boise: {
    name: "Boise",
    stateAbbr: "ID",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Outdoor equipment moving assistance",
      "Apartment and condo moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Boise typically charge between $28-$50 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Boise, with flexible scheduling to accommodate your needs. Many helpers offer special winter moving expertise for snow and ice conditions.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Idaho moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Boise building regulations",
      "Equipped for all-weather moving conditions",
    ],
    commonRequests: [
      "Help with North End historic home moves",
      "Assistance with winter weather moving",
      "Moving to/from foothills homes with difficult access",
      "Help with downtown condo moves",
      "Assistance with HOA moving restrictions",
    ],
    serviceAreas: [
      "Downtown Boise",
      "North End",
      "East End",
      "Bench",
      "Southeast Boise",
      "Meridian",
      "Eagle",
      "Nampa",
      "Garden City",
      "Kuna",
    ],
  },
  raleigh: {
    name: "Raleigh",
    stateAbbr: "NC",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Tech equipment moving assistance",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Raleigh typically charge between $30-$52 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Raleigh, with many offering extended hours during peak moving season. Helpers work around university schedules to avoid the busiest campus moving times.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in North Carolina moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Raleigh building regulations",
      "Specialized in handling tech equipment",
    ],
    commonRequests: [
      "Help with downtown Raleigh parking challenges",
      "Assistance with university area moves",
      "Moving in historic districts with restrictions",
      "Help with Research Triangle Park office moves",
      "Assistance with high humidity moving conditions",
    ],
    serviceAreas: [
      "Downtown Raleigh",
      "North Hills",
      "Glenwood South",
      "Five Points",
      "Cameron Village",
      "Cary",
      "Durham",
      "Chapel Hill",
      "Wake Forest",
      "Apex",
    ],
  },
  phoenix: {
    name: "Phoenix",
    stateAbbr: "AZ",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Pool and patio equipment moving",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Phoenix typically charge between $32-$55 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Phoenix, with early morning appointments during summer months to avoid extreme heat. Many helpers specialize in heat-safe moving practices.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Arizona moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Phoenix building regulations",
      "Specialized in heat-safe moving practices",
    ],
    commonRequests: [
      "Early morning moves to avoid extreme heat",
      "Help with gated community moving restrictions",
      "Assistance navigating desert landscaping",
      "Help with high-rise elevator reservations",
      "Assistance during monsoon season",
    ],
    serviceAreas: [
      "Downtown Phoenix",
      "Scottsdale",
      "Tempe",
      "Mesa",
      "Chandler",
      "Gilbert",
      "Glendale",
      "Peoria",
      "Paradise Valley",
      "Ahwatukee",
    ],
  },
  tampa: {
    name: "Tampa",
    stateAbbr: "FL",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Watercraft and marine equipment moving",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Tampa typically charge between $30-$54 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Tampa, with flexible scheduling to work around afternoon thunderstorms during rainy season. Many helpers monitor weather forecasts to ensure optimal moving conditions.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Florida moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Tampa building regulations",
      "Specialized in humidity-safe moving practices",
    ],
    commonRequests: [
      "Help scheduling around afternoon thunderstorms",
      "Assistance during hurricane season",
      "Moving to/from waterfront properties",
      "Help with high-rise condo elevator reservations",
      "Assistance in historic Ybor City with narrow streets",
    ],
    serviceAreas: [
      "Downtown Tampa",
      "South Tampa",
      "Ybor City",
      "Hyde Park",
      "Davis Islands",
      "St. Petersburg",
      "Clearwater",
      "Brandon",
      "Wesley Chapel",
      "Riverview",
    ],
  },
  charlotte: {
    name: "Charlotte",
    stateAbbr: "NC",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Office equipment moving assistance",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Charlotte typically charge between $30-$52 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Charlotte, with extended hours during peak moving season. Many helpers work around major events at Bank of America Stadium and Spectrum Center.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in North Carolina moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Charlotte building regulations",
      "Specialized in office equipment handling",
    ],
    commonRequests: [
      "Help with Uptown Charlotte parking challenges",
      "Assistance with high-rise COI requirements",
      "Moving in historic districts with restrictions",
      "Help scheduling around major sporting events",
      "Assistance with new construction area moves",
    ],
    serviceAreas: [
      "Uptown Charlotte",
      "South End",
      "NoDa",
      "Plaza Midwood",
      "Dilworth",
      "Ballantyne",
      "Huntersville",
      "Matthews",
      "Concord",
      "Rock Hill",
    ],
  },
  denver: {
    name: "Denver",
    stateAbbr: "CO",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Outdoor and ski equipment moving",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Denver typically charge between $35-$58 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Denver, with flexible scheduling to accommodate weather conditions. Many helpers specialize in winter moving with snow and ice precautions.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Colorado moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Denver building regulations",
      "Specialized in high-altitude moving considerations",
    ],
    commonRequests: [
      "Help with winter weather moving conditions",
      "Assistance with downtown Denver parking permits",
      "Moving in high-rise buildings with specific hours",
      "Help with historic building restrictions",
      "Assistance with altitude considerations for items",
    ],
    serviceAreas: [
      "Downtown Denver",
      "LoDo",
      "RiNo",
      "Highland",
      "Cherry Creek",
      "Aurora",
      "Lakewood",
      "Arvada",
      "Westminster",
      "Centennial",
    ],
  },
  columbus: {
    name: "Columbus",
    stateAbbr: "OH",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "University moving assistance",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Columbus typically charge between $28-$50 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Columbus, with extended hours during peak moving season. Many helpers work around Ohio State football games and major events to ensure smooth scheduling.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Ohio moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Columbus building regulations",
      "Specialized in university campus moves",
    ],
    commonRequests: [
      "Help scheduling around Ohio State events",
      "Assistance with German Village narrow streets",
      "Moving with downtown Columbus parking restrictions",
      "Help with older homes' narrow doorways",
      "Assistance with winter weather moving",
    ],
    serviceAreas: [
      "Downtown Columbus",
      "Short North",
      "German Village",
      "Victorian Village",
      "Clintonville",
      "Dublin",
      "Westerville",
      "Gahanna",
      "Hilliard",
      "Worthington",
    ],
  },
  "salt-lake-city": {
    name: "Salt Lake City",
    stateAbbr: "UT",
    helperServices: [
      "Loading and unloading assistance",
      "Furniture assembly and disassembly",
      "Packing and unpacking help",
      "Mountain and outdoor equipment moving",
      "Apartment and high-rise moving help",
      "Commercial office moving assistance",
    ],
    pricing:
      "Moving helpers in Salt Lake City typically charge between $30-$55 per hour per helper. Our platform connects you with helpers at competitive rates, with transparent pricing and no hidden fees.",
    availability:
      "Moving helpers are available 7 days a week in Salt Lake City, with flexible scheduling to accommodate weather conditions. Many helpers specialize in winter moving with snow and ice precautions.",
    helperQualifications: [
      "Background-checked and verified",
      "Experienced in Utah moves",
      "Trained in proper lifting techniques",
      "Knowledgeable about Salt Lake City building regulations",
      "Specialized in mountain area moving challenges",
    ],
    commonRequests: [
      "Help with winter weather moving conditions",
      "Assistance with canyon home access challenges",
      "Moving in downtown buildings with specific hours",
      "Help scheduling around university events",
      "Assistance with historic district requirements",
    ],
    serviceAreas: [
      "Downtown Salt Lake City",
      "Sugar House",
      "The Avenues",
      "Capitol Hill",
      "9th and 9th",
      "Millcreek",
      "Holladay",
      "Sandy",
      "Draper",
      "South Jordan",
    ],
  },
}

export default function CitySpecificContent({ cityInfo }: CitySpecificContentProps) {
  return (
    <div className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">
          Moving Help in {cityInfo.name}, {cityInfo.stateAbbr}
        </h1>

        <p className="text-lg text-gray-700 mb-12 max-w-3xl mx-auto text-center">
          Redhawk Relocation connects you with professional moving helpers throughout {cityInfo.name}. Our platform
          matches you with verified, independent moving helpers who can assist with your specific moving needs.
        </p>

        {/* Moving Services */}
        <div className="mb-12 bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <Truck className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-semibold text-gray-800">Moving Help Services in {cityInfo.name}</h2>
          </div>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {cityInfo.helperServices.map((service, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{service}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Pricing */}
        <div className="mb-12 bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <DollarSign className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-semibold text-gray-800">{cityInfo.name} Moving Helper Rates</h2>
          </div>
          <p className="text-gray-700">{cityInfo.pricing}</p>
        </div>

        {/* Availability */}
        <div className="mb-12 bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <Clock className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-semibold text-gray-800">Helper Availability in {cityInfo.name}</h2>
          </div>
          <p className="text-gray-700">{cityInfo.availability}</p>
        </div>

        {/* Helper Qualifications */}
        <div className="mb-12 bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <Users className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-semibold text-gray-800">{cityInfo.name} Helper Qualifications</h2>
          </div>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {cityInfo.helperQualifications.map((qualification, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{qualification}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Common Requests */}
        <div className="mb-12 bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <ShieldCheck className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-semibold text-gray-800">Common Moving Requests in {cityInfo.name}</h2>
          </div>
          <ul className="space-y-2">
            {cityInfo.commonRequests.map((request, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{request}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Service Areas */}
        <div className="mb-12 bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <MapPin className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-semibold text-gray-800">{cityInfo.name} Areas We Serve</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {cityInfo.serviceAreas.map((area, index) => (
              <div key={index} className="bg-white p-3 rounded shadow-sm border border-gray-100 text-center">
                <span className="font-medium text-gray-700">{area}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Need Moving Help in {cityInfo.name}?</h3>
          <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
            Let Redhawk Relocation connect you with the best independent moving helpers in {cityInfo.name}. Our platform
            makes it easy to find reliable, affordable moving assistance.
          </p>
          <Link href="/quote">
            <Button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-md font-medium">
              Find Moving Helpers
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

export { cityData }
