export function ContactHero() {
  return <section className="relative bg-white border-b border-gray-100"></section>
}
