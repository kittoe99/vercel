import { Logo } from "@/components/logo"
import Link from "next/link"
import { Facebook, Instagram, Twitter, Linkedin, ArrowRight, MapPin, Phone, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-secondary-900 text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 z-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="footerGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#footerGrid)" />
        </svg>
      </div>

      {/* Top wave divider */}
      <div className="relative">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          className="w-full h-auto text-white"
        >
          <path
            d="M0 0L60 10C120 20 240 40 360 50C480 60 600 60 720 55C840 50 960 40 1080 30C1200 20 1320 10 1380 5L1440 0V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V0Z"
            fill="currentColor"
          />
        </svg>
      </div>

      <div className="container py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          <div className="md:col-span-4">
            <Logo />
            <p className="mt-6 text-secondary-300 max-w-md">
              A technology platform connecting you with independent moving professionals. Book reliable moving help
              quickly and easily while you focus on your new beginning.
            </p>
            <div className="flex space-x-4 mt-8">
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-secondary-800 flex items-center justify-center hover:bg-primary-600 transition-colors"
              >
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-secondary-800 flex items-center justify-center hover:bg-primary-600 transition-colors"
              >
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-secondary-800 flex items-center justify-center hover:bg-primary-600 transition-colors"
              >
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-secondary-800 flex items-center justify-center hover:bg-primary-600 transition-colors"
              >
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>

          <div className="md:col-span-2">
            <h3 className="text-lg font-semibold mb-6 relative inline-block">
              Quick Links
              <span className="absolute -bottom-2 left-0 w-12 h-1 bg-primary-600"></span>
            </h3>
            <ul className="space-y-4">
              <li>
                <Link
                  href="#"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Home</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#about"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>About Us</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#services"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Services</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#testimonials"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Testimonials</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#contact"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Contact</span>
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h3 className="text-lg font-semibold mb-6 relative inline-block">
              Services
              <span className="absolute -bottom-2 left-0 w-12 h-1 bg-primary-600"></span>
            </h3>
            <ul className="space-y-4">
              <li>
                <Link
                  href="#"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Local Moving</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Long Distance Moving</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Packing Services</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Storage Solutions</span>
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-secondary-300 hover:text-white transition-colors flex items-center group"
                >
                  <ArrowRight className="h-4 w-0 mr-0 opacity-0 group-hover:w-4 group-hover:mr-2 group-hover:opacity-100 transition-all text-primary-600" />
                  <span>Commercial Moving</span>
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <h3 className="text-lg font-semibold mb-6 relative inline-block">
              Contact Info
              <span className="absolute -bottom-2 left-0 w-12 h-1 bg-primary-600"></span>
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <div className="mr-4 p-2 bg-secondary-800 rounded-full mt-1">
                  <MapPin className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <p className="text-secondary-300">
                    6001 W Parmer Lane
                    <br />
                    Ste 370, Austin, TX 78727, United States
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="mr-4 p-2 bg-secondary-800 rounded-full mt-1">
                  <Phone className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <p className="text-secondary-300">(555) 123-4567</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="mr-4 p-2 bg-secondary-800 rounded-full mt-1">
                  <Mail className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <p className="text-secondary-300">info@redhawkrelocation.com</p>
                </div>
              </li>
            </ul>

            <div className="mt-8 bg-secondary-800 p-6 rounded-xl">
              <h4 className="font-semibold mb-4">Subscribe to Our Newsletter</h4>
              <form className="flex">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="flex-1 py-2 px-4 bg-secondary-700 text-white rounded-l-lg focus:outline-none focus:ring-2 focus:ring-primary-600"
                />
                <button
                  type="submit"
                  className="bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded-r-lg transition-colors"
                >
                  <ArrowRight className="h-5 w-5" />
                </button>
              </form>
            </div>
          </div>
        </div>

        <div className="border-t border-secondary-800 mt-8 pt-6 text-center text-secondary-400 text-sm">
          <p className="max-w-3xl mx-auto">
            <strong>Disclaimer:</strong> Redhawk Relocation is not a moving company. We are a technology platform that
            connects customers with independent moving professionals. All moving services are provided by independent
            third-party contractors who use our platform. We do not own trucks or transport goods ourselves.
          </p>
        </div>

        <div className="border-t border-secondary-800 mt-16 pt-8 text-center text-secondary-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Redhawk Relocation. All rights reserved.</p>
          <div className="mt-4 space-x-6">
            <Link href="#" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-white transition-colors">
              Terms of Service
            </Link>
            <Link href="#" className="hover:text-white transition-colors">
              Sitemap
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
