import * as React from "react"
import { cn } from "@/lib/utils"

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  textAlign?: "left" | "center" | "right"
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, textAlign = "left", ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-14 w-full rounded-xl border-2 border-gray-300 bg-white px-4 py-3 text-2xl font-medium text-gray-900",
          "placeholder:text-gray-500",
          "placeholder:text-xl",
          "focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500",
          "hover:border-primary-400 transition-colors duration-200",
          "disabled:cursor-not-allowed disabled:opacity-50",
          textAlign === "center" && "text-center placeholder:text-center",
          textAlign === "right" && "text-right placeholder:text-right",
          "md:h-14 md:text-xl md:placeholder:text-xl",
          className,
        )}
        autoComplete={type === "tel" ? "tel" : "on"}
        inputMode={type === "tel" ? "tel" : undefined}
        ref={ref}
        style={{
          fontSize: type === "tel" ? "1.5rem" : "1.25rem",
          lineHeight: "1.75rem",
          backgroundColor: type === "tel" ? "#FFEEEE" : "white",
          color: type === "tel" ? "#990000" : "#111827",
          borderColor: type === "tel" ? "#FFAAAA" : "",
          ...(type === "tel" && {
            "::placeholder": {
              color: "#B08080",
            },
          }),
        }}
        {...props}
      />
    )
  },
)
Input.displayName = "Input"

// Add custom styles for telephone input placeholders
if (typeof document !== "undefined") {
  const style = document.createElement("style")
  style.innerHTML = `
    input[type="tel"]::placeholder {
      color: #B08080 !important;
    }
  `
  document.head.appendChild(style)
}

export { Input }
